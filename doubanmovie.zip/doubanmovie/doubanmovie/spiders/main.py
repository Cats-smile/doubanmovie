from scrapy import cmdline

name='douban_movie -o douban2.csv'
cmd = 'scrapy crawl {0}'.format(name)
cmdline.execute(cmd.split())

# name='douban2 -o douban2.csv'
# cmd = 'scrapy crawl douban2'.format(name)
# cmdline.execute(cmd.split())
#
#
